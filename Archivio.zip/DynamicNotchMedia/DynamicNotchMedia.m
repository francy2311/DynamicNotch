#import "DynamicNotchMedia.h"

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <dlfcn.h>

#include "EXTERN.h"
#include "perl.h"
#include "XSUB.h"

// MARK: - MediaRemote Types

typedef void (*MRGetNowPlayingInfoFunction)(
    dispatch_queue_t queue,
    void (^callback)(CFDictionaryRef _Nullable information)
);

typedef Boolean (*MRSendCommandFunction)(
    int command,
    CFDictionaryRef _Nullable userInfo
);

typedef void (*MRSetElapsedTimeFunction)(
    double elapsedTime
);

// MARK: - MediaRemote Handle

static void *mediaRemoteHandle(void) {

    static void *handle = NULL;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{

        const char *frameworkPath =
            "/System/Library/PrivateFrameworks/"
            "MediaRemote.framework/MediaRemote";

        handle = dlopen(
            frameworkPath,
            RTLD_NOW
        );

        if (handle == NULL) {

            NSLog(
                @"DynamicNotchMedia: unable to load MediaRemote"
            );
        }
    });

    return handle;
}

// MARK: - Get Now Playing Function

static MRGetNowPlayingInfoFunction
getNowPlayingInfoFunction(void) {

    static MRGetNowPlayingInfoFunction function = NULL;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{

        void *handle = mediaRemoteHandle();

        if (handle == NULL) {
            return;
        }

        function =
            (MRGetNowPlayingInfoFunction)
            dlsym(
                handle,
                "MRMediaRemoteGetNowPlayingInfo"
            );

        if (function == NULL) {

            NSLog(
                @"DynamicNotchMedia: "
                @"MRMediaRemoteGetNowPlayingInfo not found"
            );
        }
    });

    return function;
}

// MARK: - Send Command Function

static MRSendCommandFunction
sendCommandFunction(void) {

    static MRSendCommandFunction function = NULL;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{

        void *handle = mediaRemoteHandle();

        if (handle == NULL) {
            return;
        }

        function =
            (MRSendCommandFunction)
            dlsym(
                handle,
                "MRMediaRemoteSendCommand"
            );

        if (function == NULL) {

            NSLog(
                @"DynamicNotchMedia: "
                @"MRMediaRemoteSendCommand not found"
            );
        }
    });

    return function;
}

// MARK: - Seek Function

static MRSetElapsedTimeFunction
setElapsedTimeFunction(void) {

    static MRSetElapsedTimeFunction function = NULL;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{

        void *handle = mediaRemoteHandle();

        if (handle == NULL) {
            return;
        }

        function =
            (MRSetElapsedTimeFunction)
            dlsym(
                handle,
                "MRMediaRemoteSetElapsedTime"
            );

        if (function == NULL) {

            NSLog(
                @"DynamicNotchMedia: "
                @"MRMediaRemoteSetElapsedTime not found"
            );
        }
    });

    return function;
}

// MARK: - Normalize Metadata

static NSDictionary *
normalizedNowPlayingDictionary(
    NSDictionary *raw
) {

    if (raw == nil) {
        return nil;
    }

    NSMutableDictionary *result =
        [NSMutableDictionary dictionary];

    NSString *title =
        raw[
            @"kMRMediaRemoteNowPlayingInfoTitle"
        ];

    NSString *artist =
        raw[
            @"kMRMediaRemoteNowPlayingInfoArtist"
        ];

    NSString *album =
        raw[
            @"kMRMediaRemoteNowPlayingInfoAlbum"
        ];

    NSNumber *duration =
        raw[
            @"kMRMediaRemoteNowPlayingInfoDuration"
        ];

    NSNumber *elapsedTime =
        raw[
            @"kMRMediaRemoteNowPlayingInfoElapsedTime"
        ];

    NSNumber *playbackRate =
        raw[
            @"kMRMediaRemoteNowPlayingInfoPlaybackRate"
        ];

    NSDate *timestamp =
        raw[
            @"kMRMediaRemoteNowPlayingInfoTimestamp"
        ];

    if (title != nil) {
        result[@"title"] = title;
    }

    if (artist != nil) {
        result[@"artist"] = artist;
    }

    if (album != nil) {
        result[@"album"] = album;
    }

    if (duration != nil) {
        result[@"duration"] = duration;
    }

    if (elapsedTime != nil) {
        result[@"elapsedTime"] = elapsedTime;
    }

    if (playbackRate != nil) {

        result[@"playbackRate"] =
            playbackRate;

        result[@"playing"] =
            @(playbackRate.doubleValue > 0);
    }

    if (timestamp != nil) {

        result[@"timestamp"] =
            @(timestamp.timeIntervalSince1970);
    }

    return result;
}

// MARK: - Get JSON

static NSString *
dynamicNotchGetJSON(void) {

    MRGetNowPlayingInfoFunction function =
        getNowPlayingInfoFunction();

    if (function == NULL) {
        return nil;
    }

    dispatch_semaphore_t semaphore =
        dispatch_semaphore_create(0);

    __block NSDictionary *information =
        nil;

    function(
        dispatch_get_global_queue(
            QOS_CLASS_USER_INITIATED,
            0
        ),
        ^(CFDictionaryRef info) {

            if (info != NULL) {

                information =
                    [(__bridge NSDictionary *)info copy];
            }

            dispatch_semaphore_signal(
                semaphore
            );
        }
    );

    long waitResult =
        dispatch_semaphore_wait(
            semaphore,
            dispatch_time(
                DISPATCH_TIME_NOW,
                2 * NSEC_PER_SEC
            )
        );

    if (waitResult != 0) {

        NSLog(
            @"DynamicNotchMedia: timeout"
        );

        return nil;
    }

    if (information == nil) {
        return nil;
    }

    NSDictionary *normalized =
        normalizedNowPlayingDictionary(
            information
        );

    if (normalized == nil) {
        return nil;
    }

    NSError *error = nil;

    NSData *jsonData =
        [NSJSONSerialization
            dataWithJSONObject:normalized
            options:0
            error:&error];

    if (jsonData == nil || error != nil) {

        NSLog(
            @"DynamicNotchMedia JSON error: %@",
            error
        );

        return nil;
    }

    return [[NSString alloc]
        initWithData:jsonData
        encoding:NSUTF8StringEncoding];
}

// MARK: - Commands

static BOOL
dynamicNotchSendCommand(
    int command
) {

    MRSendCommandFunction function =
        sendCommandFunction();

    if (function == NULL) {
        return NO;
    }

    return function(
        command,
        NULL
    ) ? YES : NO;
}

static BOOL
dynamicNotchSeek(
    double seconds
) {

    if (seconds < 0) {
        seconds = 0;
    }

    MRSetElapsedTimeFunction function =
        setElapsedTimeFunction();

    if (function == NULL) {
        return NO;
    }

    function(seconds);

    return YES;
}

// MARK: - C API

const char *
dynamic_notch_media_get(void) {

    NSString *json =
        dynamicNotchGetJSON();

    if (json == nil) {
        return NULL;
    }

    return strdup(
        json.UTF8String
    );
}

void dynamic_notch_media_free(
    const char *pointer
) {

    if (pointer != NULL) {
        free(
            (void *)pointer
        );
    }
}

// MARK: - XS Get

XS(
    XS_DynamicNotchMedia_get
) {

    dXSARGS;

    if (items != 0) {

        croak(
            "Usage: DynamicNotchMedia::get()"
        );
    }

    NSString *json =
        dynamicNotchGetJSON();

    if (json == nil) {
        XSRETURN_UNDEF;
    }

    const char *utf8 =
        json.UTF8String;

    if (utf8 == NULL) {
        XSRETURN_UNDEF;
    }

    ST(0) =
        sv_2mortal(
            newSVpv(
                utf8,
                0
            )
        );

    XSRETURN(1);
}

// MARK: - XS Toggle

XS(
    XS_DynamicNotchMedia_togglePlayback
) {

    dXSARGS;

    if (items != 0) {

        croak(
            "Usage: DynamicNotchMedia::togglePlayback()"
        );
    }

    BOOL success =
        dynamicNotchSendCommand(
            2
        );

    ST(0) =
        sv_2mortal(
            newSViv(
                success ? 1 : 0
            )
        );

    XSRETURN(1);
}

// MARK: - XS Next

XS(
    XS_DynamicNotchMedia_nextTrack
) {

    dXSARGS;

    if (items != 0) {

        croak(
            "Usage: DynamicNotchMedia::nextTrack()"
        );
    }

    BOOL success =
        dynamicNotchSendCommand(
            4
        );

    ST(0) =
        sv_2mortal(
            newSViv(
                success ? 1 : 0
            )
        );

    XSRETURN(1);
}

// MARK: - XS Previous

XS(
    XS_DynamicNotchMedia_previousTrack
) {

    dXSARGS;

    if (items != 0) {

        croak(
            "Usage: DynamicNotchMedia::previousTrack()"
        );
    }

    BOOL success =
        dynamicNotchSendCommand(
            5
        );

    ST(0) =
        sv_2mortal(
            newSViv(
                success ? 1 : 0
            )
        );

    XSRETURN(1);
}

// MARK: - XS Seek

XS(
    XS_DynamicNotchMedia_seek
) {

    dXSARGS;

    if (items != 1) {

        croak(
            "Usage: DynamicNotchMedia::seek(seconds)"
        );
    }

    double seconds =
        SvNV(
            ST(0)
        );

    BOOL success =
        dynamicNotchSeek(
            seconds
        );

    ST(0) =
        sv_2mortal(
            newSViv(
                success ? 1 : 0
            )
        );

    XSRETURN(1);
}

// MARK: - Bootstrap

EXTERN_C
XS(
    boot_DynamicNotchMedia
) {

    dXSARGS;

    char *file =
        __FILE__;

    newXS(
        "DynamicNotchMedia::get",
        XS_DynamicNotchMedia_get,
        file
    );

    newXS(
        "DynamicNotchMedia::togglePlayback",
        XS_DynamicNotchMedia_togglePlayback,
        file
    );

    newXS(
        "DynamicNotchMedia::nextTrack",
        XS_DynamicNotchMedia_nextTrack,
        file
    );

    newXS(
        "DynamicNotchMedia::previousTrack",
        XS_DynamicNotchMedia_previousTrack,
        file
    );

    newXS(
        "DynamicNotchMedia::seek",
        XS_DynamicNotchMedia_seek,
        file
    );

    XSRETURN_YES;
}
